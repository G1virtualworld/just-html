function validate(){
    var Password=document.getElementById("password").value;
    if(Password=="CAOneTechcloud"){
        window.alert("Succesfully Logined");
               
        
    }
    else{
        window.alert("Password entered is wrong");
        return false;
    }
}